package com.example.parkfast2;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;

import java.io.IOException;
import java.util.List;
import java.util.Locale;

public class MapaActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private EditText searchBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.mapa);

        ImageView reservasImageView = findViewById(R.id.reservas);
        ImageView cuentaImageView = findViewById(R.id.cuenta);

        // Configurar el clic para abrir reservas.xml
        reservasImageView.setOnClickListener(v -> {
            Intent intent = new Intent(MapaActivity.this, ReservasActivity.class);
            startActivity(intent);
        });

        // Configurar el clic para abrir cuenta.xml
        cuentaImageView.setOnClickListener(v -> {
            Intent intent = new Intent(MapaActivity.this, CuentaActivity.class);
            startActivity(intent);
        });


        // Inicializar la barra de búsqueda
        searchBar = findViewById(R.id.search_bar);

        // Detectar clic en el icono de "lupa" para buscar ubicación
        searchBar.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_UP) {
                Drawable drawableStart = searchBar.getCompoundDrawables()[0]; // DrawableStart (lupa)
                if (drawableStart != null && event.getRawX() <= (searchBar.getLeft() + drawableStart.getBounds().width())) {
                    buscarUbicacion(); // Llamar al método para buscar la ubicación
                    return true;
                }
                Drawable drawableEnd = searchBar.getCompoundDrawables()[2]; // DrawableEnd (X)
                if (drawableEnd != null && event.getRawX() >= (searchBar.getRight() - drawableEnd.getBounds().width())) {
                    // Borrar texto cuando se hace clic en la "X"
                    searchBar.setText("");
                    return true;
                }
            }
            return false;
        });

        // Mostrar u ocultar la "X" según el texto
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                Drawable drawableEnd = s.length() > 0 ?
                        getResources().getDrawable(android.R.drawable.ic_menu_close_clear_cancel) : null;
                searchBar.setCompoundDrawablesWithIntrinsicBounds(
                        getResources().getDrawable(android.R.drawable.ic_menu_search),
                        null,
                        drawableEnd,
                        null
                );
            }

            @Override
            public void afterTextChanged(Editable s) {}
        });

        // Configurar el fragmento del mapa
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        ImageView imageViewReservas = findViewById(R.id.reservas);
        imageViewReservas.setOnClickListener(v -> {
            Intent intent = new Intent(MapaActivity.this, ReservasActivity.class);
            startActivity(intent);
        });
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        // Establecer la ubicación inicial en la Playa de Gandía
        LatLng playaDeGandia = new LatLng(39.001667, -0.166111);
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(playaDeGandia, 14));

        // Añadir marcadores de ejemplo
        LatLng parking1 = new LatLng(39.002500, -0.168000);
        LatLng parking2 = new LatLng(38.995123, -0.160942);

        mMap.addMarker(new MarkerOptions()
                        .position(parking1)
                        .title("Parking 1 - capacidad para 3 coches")
                        .snippet("Pulsa para realizar una reserva")
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.pin)))
                .setTag("parking1");  // Etiqueta para identificar este marcador

        mMap.addMarker(new MarkerOptions()
                        .position(parking2)
                        .title("Parking 2 - capacidad para 3 coches")
                        .snippet("Pulsa para realizar una reserva")
                        .icon(BitmapDescriptorFactory.fromResource(R.drawable.pin)))
                .setTag("parking2");  // Etiqueta para identificar este marcador

        // Manejo del clic en un marcador
        mMap.setOnInfoWindowClickListener(marker -> {
            if (marker.getTag().equals("parking1")) {
                abrirReservaActivity1();  // Abre la actividad para Parking 1
            } else if (marker.getTag().equals("parking2")) {
                abrirReservaActivity2();  // Abre la actividad para Parking 2
            }
        });
    }

    // Método para abrir la actividad de reserva para Parking 1
    private void abrirReservaActivity1() {
        Intent intent = new Intent(MapaActivity.this, ReservaActivity1.class);
        startActivity(intent);
    }

    // Método para abrir la actividad de reserva para Parking 2
    private void abrirReservaActivity2() {
        Intent intent = new Intent(MapaActivity.this, ReservaActivity2.class);
        startActivity(intent);
    }


    // Método para buscar la ubicación
    private void buscarUbicacion() {
        String ubicacion = searchBar.getText().toString();

        if (ubicacion.isEmpty()) {
            Toast.makeText(this, "Por favor, introduce una ubicación.", Toast.LENGTH_SHORT).show();
            return;
        }

        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> direcciones = geocoder.getFromLocationName(ubicacion, 1);
            if (direcciones != null && !direcciones.isEmpty()) {
                Address direccion = direcciones.get(0);
                LatLng latLng = new LatLng(direccion.getLatitude(), direccion.getLongitude());

                // Mover la cámara y añadir un marcador en la ubicación buscada
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 14));
                mMap.addMarker(new MarkerOptions()
                        .position(latLng)
                        .title(ubicacion)
                        .icon(BitmapDescriptorFactory.defaultMarker()));
            } else {
                Toast.makeText(this, "No se encontró la ubicación especificada.", Toast.LENGTH_SHORT).show();
            }
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "Error al buscar la ubicación. Intenta nuevamente.", Toast.LENGTH_SHORT).show();
        }
    }
}
